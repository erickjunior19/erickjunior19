Nom:Philippe
Prenom:Erick Junior
Code:33461
Option:sces informatiques
Vacation:Median